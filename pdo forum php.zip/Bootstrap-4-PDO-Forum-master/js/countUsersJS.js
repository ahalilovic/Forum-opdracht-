// Live refresh
$(document).ready(function () {
    countUsers();
});
function countUsers() {
    $('#countUsers').load("app/countUsers.php");
    setTimeout(countUsers, 5000);
}