// Live refresh
$(document).ready(function () {
    fetchThreadAndReplies();
});
function fetchThreadAndReplies() {
    $('#fetchThreadAndReplies').load("app/fetchThreadAndReplies.php");
    setTimeout(fetchThreadAndReplies, 5000);
}