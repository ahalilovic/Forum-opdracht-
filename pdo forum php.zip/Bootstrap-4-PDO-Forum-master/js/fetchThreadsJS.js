// Live refresh
$(document).ready(function () {
    fetchThreads();
});
function fetchThreads() {
    $('#fetchThreads').load("app/fetchThreads.php");
    setTimeout(fetchThreads, 5000);
}