<?php
// Are you logged in?
session_start();
if(!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit(0);
} elseif ($_SESSION['admin'] == true) {
    $admin = '<li class="nav-item"><a class="nav-link" href="adminpanel.php">Admin panel</a></li>';
} else {
    $admin = null;
}
// Thread handler
include('app/createThread.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Site name -->
    <title>Bootstrap 4 Forum | Create thread</title>
    <!-- Style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css"><!-- Little fixes and spacing -->
</head>
<body>
<!-- Actual page -->
<nav class="navbar navbar-toggleable-md navbar-light bg-faded fixed-top">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">Bootstrap 4 Forum</a>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
                <?= $admin ?>
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Home</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="create.php">Create thread <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Logout</a>
                </li>
            </ul>
            <span class="navbar-text">
            You are signed in as <?= $_SESSION['username'] ?>
        </span>
        </div>
    </div>
</nav>
<!-- Create a thread -->
<div class="container margin-top">
    <div class="row">
        <div class="col-md-10 offset-md-1">
            <div class="card">
                <div class="card-header">
                    Create a new thread
                </div>
                <form method="post">
                    <div class="card-block">
                        <form method="post">
                            <div class="form-group">
                                <label for="threadtitle">Thread title</label>
                                <input name="thread_title" type="text" class="form-control" id="threadtitle" maxlength="24">
                                <?= $title_error ?>
                            </div>
                            <div class="form-group">
                                <label for="textarea">Thread content</label>
                                <textarea name="thread_content" class="form-control" id="textarea" rows="3" maxlength="1000"></textarea>
                                <?= $content_error ?>
                            </div>
                            <?= $create_thread_msg ?>
                            <button name="create_thread" type="submit" class="btn btn-primary">Create</button>
                        </form>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Scripts -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
</body>
</html>