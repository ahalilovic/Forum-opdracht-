<?php
// Are you logged in?
session_start();
if(!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit(0);
} elseif (!$_SESSION['admin'] == true) {
    header('Location: dashboard.php');
    exit(0);
}
// Adminpanel handler
include 'app/adminpanel-handler.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Site name -->
    <title>Bootstrap 4 Forum | Admin panel</title>
    <!-- Style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css"><!-- Little fixes and spacing -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<!-- Actual page -->
<nav class="navbar navbar-toggleable-md navbar-light bg-faded fixed-top">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">Bootstrap 4 Forum</a>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="adminpanel.php">Admin panel <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="create.php">Create thread</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="app/logout.php">Logout</a>
                </li>
            </ul>
            <span class="navbar-text">
            You are signed in as <?= $_SESSION['username'] ?>
        </span>
        </div>
    </div>
</nav>
<!-- Admin panel -->
<div class="container-fluid margin-top">
    <div class="row">
        <div class="col-md-4">
            <div class="card mt-2 mb-2">
                <div class="card-header">
                    <i class="fa fa-bookmark fa-fw fa-lg" aria-hidden="true"></i>
                    Amount of threads
                </div>
                <div class="card-block">
                    <h4 class="card-title"><?= $count_threads ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mt-2 mb-2">
                <div class="card-header">
                    <i class="fa fa-comments fa-fw fa-lg" aria-hidden="true"></i>
                    Amount of replies
                </div>
                <div class="card-block">
                    <h4 class="card-title"><?= $count_replies ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mt-2 mb-2">
                <div class="card-header">
                    <i class="fa fa-users fa-fw fa-lg" aria-hidden="true"></i>
                    Amount of users
                </div>
                <div class="card-block">
                    <h4 class="card-title"><?= $count_users ?></h4>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card mt-2 mb-2">
                <div class="card-header">
                    <i class="fa fa-user fa-fw fa-lg" aria-hidden="true"></i>
                    User overview
                </div>
                <div class="card-block">
                    <?= $user_msg ?>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Username</th>
                            <th>Admin</th>
                            <th>Email</th>
                            <th>Remove</th>
                            <th>Make admin</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php fetchUsers($dbh); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mt-2 mb-2">
                <div class="card-header">
                    <i class="fa fa-bookmark-o fa-fw fa-lg" aria-hidden="true"></i>
                    Thread overview
                </div>
                <div class="card-block">
                    <?= $thread_msg ?>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Author</th>
                            <th>Title</th>
                            <th>Remove</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php fetchThreads($dbh); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Scripts -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
</body>
</html>