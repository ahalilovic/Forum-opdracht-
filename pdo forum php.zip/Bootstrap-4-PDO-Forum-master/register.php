<?php
// Are you logged in?
session_start();
if(isset($_SESSION['username'])) {
    header('Location: dashboard.php');
    exit(0);
}
// Register handler
include('app/register-handler.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Site name -->
    <title>Bootstrap 4 Forum | Register</title>
    <!-- Style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css"><!-- Little fixes and spacing -->
</head>
<body>
<!-- Actual page -->
<div class="container margin-top">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    Register
                </div>
                <div class="card-block">
                    <form method="post">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input name="username" type="text" class="form-control" aria-describedby="usernamehelp" id="username" maxlength="24">
                            <?= $username_used ?>
                            <p id="usernamehelp" class="form-text text-muted">
                                Your username can not be longer than 24 characters.
                            </p>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input name="email" type="email" class="form-control" id="email" maxlength="24">
                            <?= $email_used ?>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input name="password" type="password" id="password" class="form-control" aria-describedby="passwordhelp" maxlength="255">
                            <p id="passwordhelp" class="form-text text-muted">
                                Your password must be 8-20 characters long, contain letters and numbers,
                                and must not contain spaces, special characters, or emoji.
                            </p>
                            <?= $password_error ?>
                        </div>
                        <div class="form-group">
                            <label for="confirmpassword">Confirm password</label>
                            <input name="confirmpassword" type="password" class="form-control" id="confirmpassword" maxlength="255">
                            <?= $no_match ?>
                        </div>
                        <?= $register_message ?>
                        <button name="register" type="submit" class="btn btn-primary">Register</button>
                    </form>
                </div>
                <div class="card-footer text-muted">
                    Already have an account? <a href="index.php">Login!</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Scripts -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
</body>
</html>