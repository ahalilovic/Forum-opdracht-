<?php
// login
session_start();
if(isset($_SESSION['username'])) {
    header('Location: dashboard.php');
    exit(0);
}
// login handler
include('app/login-handler.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- eta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- site name -->
    <title>Bootstrap 4 Forum | Login</title>
    <!-- style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css"><!-- Little fixes and spacing -->
</head>
<body>
<!-- pagina -->
<div class="container margin-top">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    Login
                </div>
                <div class="card-block">
                    <form method="post">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input name="username" type="text" class="form-control" id="username" maxlength="24">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input name="password" type="password" class="form-control" id="password" maxlength="255">
                        </div>
                        <?= $login_message ?>
                        <button name="login" type="submit" class="btn btn-primary">Login</button>
                    </form>
                </div>
                <div class="card-footer text-muted">
                    Not registerd? <a href="register.php">Register!</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Scripts -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
</body>
</html>