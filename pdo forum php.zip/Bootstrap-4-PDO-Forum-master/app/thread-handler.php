<?php
// Database connection
include('dbh.php');
// Worst piece of code ever
function worstPieceOfCodeEver($dbh) {
    // Empty vars
    $content_error = null;
    $create_reply_msg = null;
    $remove = null;
    $deletepost_msg = null;
    $deletereply_msg = null;
// Get current post threads
    $fetch_thread = $dbh->prepare('select * from threads where id = :id');
    $fetch_thread->execute([
        ':id' => $_GET['id']
    ]);
// Get replies from this thread
    $fetch_replies = $dbh->prepare('select * from replies where id = :id');
    $fetch_replies->execute([
        ':id' => $_GET['id']
    ]);
// Display data, good luck trying to decode this xD
    if ($fetch_thread->rowCount() > 0) {
        $row = $fetch_thread->fetch();
        echo '<div class="card">';
        echo '<div class="card-block">';
        echo '<h4 class="card-title">'.$row['title'].'</h4>';
        echo '<h6 class="card-subtitle mb-2 text-muted">'.$row['author'].'</h6>';
        echo '<p class="card-text">'.$row['content'].'</p>';
        if ($row['author'] === $_SESSION['username']) {
            echo '<form method="post">';
            echo '<button name="delete_post" type="submit" class="btn btn-danger">Delete thread</button>';
            echo '</form>';
        } else {
            echo '';
        }
        echo '</div>';
        echo '<div class="card-footer text-muted">Created at '.$row['created'].'</div>';
        echo '</div>';
        echo $deletepost_msg;
    } else {
        echo "<div class=\"card mt-2\"><div class=\"card-block\"><h4 class=\"card-title\">This post does not exist!</h4><a href=\"dashboard.php\" class=\"card-link\">Return</a></div><div class='card-footer text-muted'>Oops...</div></div>";
    };
    if (!$fetch_thread->rowCount() > 0) {
        echo '';
    } else {
        echo '<div class="card mt-2 mb-2">';
        echo '<div class="card-block">';
        echo '<form method="post">';
        echo '<div class="form-group">';
        echo '<label for="textarea">Reply content</label>';
        echo '<textarea name="reply_content" class="form-control" id="textarea" rows="2" maxlength="1000"></textarea>';
        echo $content_error;
        echo '</div>';
        echo $create_reply_msg;
        echo '<button name="create_reply" type="submit" class="btn btn-primary">Reply</button>';
        echo '</form>';
        echo '</div>';
        echo '</div>';
    }
    if ($fetch_replies->rowCount() > 0) {
        $rows = $fetch_replies->fetchAll();
        foreach ($rows as $row) {
            echo '<div class="card mt-2 mb-2">';
            echo '<div class="card-block">';
            echo '<h6 class="card-subtitle mb-2 text-muted">' . $row['author'] . '</h6>';
            echo '<p class="card-text">' . $row['content'] . '</p>';
            echo '</div>';
            echo '<div class="card-footer text-muted">Created at ' . $row['created'] . '</div>';
            echo '</div>';
        }
    }
}
// Did you press the create reply button?
if (isset($_POST['create_reply'])) {
    $author = $_SESSION['username'];
    $reply_content = htmlentities($_POST['reply_content']);
    if (!$reply_content) {
        $content_error = '<p class="text-danger">Bruh, enter some text!</p>';
    } else {
        $create_reply = $dbh->prepare('insert into replies (author, content, id) values (:author, :content, :id)');
        $create_reply->execute([
            ':author' => $author,
            ':id' => $_GET['id'],
            ':content' => $reply_content
        ]);
        $create_reply_msg = '<div class="alert alert-success" role="alert">Your reply has been posted</div>';
    }
}
// Delete post
if (isset($_POST['delete_post'])) {
    $deletepost = $dbh->prepare('delete from threads where id = :id; delete from replies where id = :id');
    $deletepost->execute([
        ':id' => $_GET['id']
    ]);
    $deletepost_msg = '<div class="alert alert-success mt-3" role="alert">Your thread has been deleted!</div>';
}