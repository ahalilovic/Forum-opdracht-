<?php
// Database connection
include('dbh.php');
// Fetch all users file for jQuery/Ajax
$fetch_threads = $dbh->prepare('select count(*) from users');
$fetch_threads->execute();
echo $fetch_threads->fetchColumn();