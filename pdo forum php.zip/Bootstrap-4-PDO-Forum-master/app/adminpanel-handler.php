<?php
// Database connection
include('dbh.php');
// Empty vars
$user_msg = null;
$thread_msg = null;
// basic queries
$qry_count_threads = $dbh->prepare('select count(*) from threads');
$qry_count_threads->execute();
$count_threads = $qry_count_threads->fetchColumn();
$qry_count_replies = $dbh->prepare('select count(*) from replies');
$qry_count_replies->execute();
$count_replies = $qry_count_replies->fetchColumn();
$qry_count_users = $dbh->prepare('select count(*) from users');
$qry_count_users->execute();
$count_users = $qry_count_users->fetchColumn();
// Fetch theads with handler
function fetchThreads($dbh) {
    $fetch_threads = $dbh->prepare('select * from threads order by id desc');
    $fetch_threads->execute();
    if (!$fetch_threads->rowCount() > 0) {
        echo '<div class="alert alert-info" role="alert">There are no threads, did you remove all of them?!</div>';
    } else {
        $rows = $fetch_threads->fetchAll();
        foreach ($rows as $row) {
            $id = $row['id'];
            $author = $row['author'];
            $title = $row['title'];
            echo '<tr>';
            echo "<td>$id</td>";
            echo "<td>$author</td>";
            echo "<td>$title</td>";
            echo "<td><form method='post'><input type='hidden' name='id' value='$id'><button name='del_thread' type='submit' class='btn btn-outline-danger'>Remove</button></form></td>";
            echo '</tr>';
        }
    }
}
// Fetch users with options
function fetchUsers($dbh) {
    $fetch_users = $dbh->prepare('select * from users');
    $fetch_users->execute();
    if (!$fetch_users->rowCount() > 0) {
        echo '<div class="alert alert-info" role="alert">There are no users, did you remove all of them?!</div>';
    } else {
        $rows = $fetch_users->fetchAll();
        foreach ($rows as $row) {
            $username = $row['username'];
            $admin = $row['admin'];
            $email = $row['email'];
            echo '<tr>';
            echo "<td>$username</td>";
            echo "<td>$admin</td>";
            echo "<td>$email</td>";
            echo "<td><form method='post'><input type='hidden' name='name' value='$username'><button name='del_user' type='submit' class='btn btn-outline-danger'>Remove</button></form></td>";
            echo "<td><form method='post'><input type='hidden' name='name' value='$username'><button name='admin_user' type='submit' class='btn btn-outline-success'>Make admin</button></form></td>";
            echo '</tr>';
        }
    }
}
// Action handlers
if (isset($_POST['del_user'])) {
    $username = $_POST['name'];
    $deleteuser = $dbh->prepare('delete from users where username = :username');
    $deleteuser->execute([
        ':username' => $username
    ]);
    $user_msg = '<div class="alert alert-danger" role="alert">User has been removed.</div>';
}
if (isset($_POST['admin_user'])) {
    $username = $_POST['name'];
    $adminuser = $dbh->prepare('update users set admin = 1 where username = :username');
    $adminuser->execute([
        ':username' => $username
    ]);
    $user_msg = '<div class="alert alert-success" role="alert">User has been made admin.</div>';
}
if (isset($_POST['del_thread'])) {
    $id = $_POST['id'];
    $deletethread = $dbh->prepare('delete from threads where id = :id; delete from replies where id = :id');
    $deletethread->execute([
        ':id' => $id
    ]);
    $thread_msg = '<div class="alert alert-danger" role="alert">Thread has been removed.</div>';
}