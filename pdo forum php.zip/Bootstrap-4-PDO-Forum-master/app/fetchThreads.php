<?php
// Database connection
include ('dbh.php');
// Fetch all threads file for jQuery/Ajax
$fetch_threads = $dbh->prepare('select * from threads order by id desc');
$fetch_threads->execute();
if ($fetch_threads->rowCount() > 0) {
    $rows = $fetch_threads->fetchAll();
    foreach ($rows as $row) {
        $id = $row['id'];
        $title = $row['title'];
        $author = $row['author'];
        $created = $row['created'];
        echo '<div class="card mt-2 mb-2">';
        echo '<div class="card-block">';
        echo "<h4 class='card-title'>$title</h4>";
        echo "<h6 class='card-subtitle mb-2 text-muted'>$author</h6>";
        echo "<a class='card-link' href='thread.php?id=$id'>Check post</a>";
        echo '</div>';
        echo "<div class='card-footer text-muted'>Created at $created</div>";
        echo '</div>';
    }
} else {
    echo "<div class=\"card mt-2 mb-2\"><div class=\"card-block\"><h4 class=\"card-title\">There are no threads!</h4><a href=\"create.php\" class=\"card-link\">Be the first one!</a></div></div>";
}