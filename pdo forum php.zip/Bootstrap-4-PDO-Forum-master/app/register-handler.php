<?php

include('dbh.php');

$register_message = null;
$username_used = null;
$email_used = null;
$password_error = null;
$no_match = null;

if (isset($_POST['register'])) {

    $username = htmlentities($_POST['username']);
    $email = htmlentities($_POST['email']);
    $password = htmlentities($_POST['password']);
    $confirmpassword = htmlentities($_POST['confirmpassword']);

    if (!$username || !$email || !$password || !$confirmpassword) {
        $register_message = '<div class="alert alert-danger" role="alert">Please fill in all fields.</div>';
    } else {

        $check_username = $dbh->prepare('select * from users where username = :username');
        $check_username->execute([
            ':username' => $username
        ]);

        $check_email = $dbh->prepare('select * from users where email = :email');
        $check_email->execute([
            ':email' => $email
        ]);

        if ($check_username->rowCount() > 0) {
            $username_used = '<p class="text-danger">Sorry, that username is taken. Try another?</p>';
        } elseif ($check_email->rowCount() > 0) {
            $email_used = '<p class="text-danger">Sorry, that email is taken. Try another?</p>';
        } elseif (strlen($password) < 7) {
            $password_error = '<p class="text-danger">Sorry, your password is too short.</p>';
        } elseif ($password != $confirmpassword) {
            $no_match = '<p class="text-danger">Sorry, your passwords do not match.</p>';
        } else {
            $create_account = $dbh->prepare('insert into users (username, email, password) values (:username, :email, :password)');
            $create_account->execute([
                ':username' => preg_replace('/\s+/', '', $username),
                ':email' => $email,
                ':password' => hash('sha512', $password)
            ]);
            $register_message = '<div class="alert alert-success" role="alert">Your account has been created, <a href="../index.php">login</a>.</div>';
        }
    }

}