<?php
// Database connection
include('dbh.php');
// Errors
$title_error = null;
$content_error = null;
$create_thread_msg = null;
// Did you press the button?
if (isset($_POST['create_thread'])) {
    $author = $_SESSION['username'];
    $thread_title = htmlentities($_POST['thread_title']);
    $thread_content = htmlentities($_POST['thread_content']);
    if (!$thread_title) {
        $title_error = '<p class="text-danger">Please enter a title.</p>';
    } elseif (!$thread_content) {
        $content_error = '<p class="text-danger">Are you trying to create a thread without text?</p>';
    } else {
        $create_thread = $dbh->prepare('insert into threads (author, title, content) values (:author, :title, :content)');
        $create_thread->execute([
            ':author' => $author,
            ':title' => $thread_title,
            ':content' => $thread_content
        ]);
        $create_thread_msg = '<div class="alert alert-success" role="alert">Your thread has been created, <a href="dashboard.php">check it out</a>!</div>';
    }
}